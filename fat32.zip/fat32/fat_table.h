#pragma once

#include <vector>
#include <cstdint>

using namespace std;

class FatTable
{
public:
    FatTable(char* buffer, int size);

    auto next(uint32_t curr) -> uint32_t;

    vector<uint32_t> fat;
};
