#include <fstream>
#include <vector>

using namespace std;


class DirectoryEntry;

class Node
{
public:
    Node(ifstream&, vector<uint32_t> clustr_nos);
    auto ExportTo(char const* path) -> bool;

private:
    vector<uint32_t> cluster_nos;
    ifstream& ifs;
};
