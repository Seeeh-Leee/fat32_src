#include <cstdint>
#include "util.h"

namespace io {

    int to_be(char* bytes)
    {
        return ((int)bytes[0] << 24) | ((int)bytes[1] << 16) |
            ((int)bytes[2] << 8) | ((int)bytes[3] << 0);
    }

    int to_le1(char* bytes)
    {
        return *(int8_t *)(char *)bytes;
    }

    int to_le2(char* bytes)
    {
        return *(int16_t *)(char *)bytes;
    }

    int to_le4(char* bytes)
    {
        return *(int32_t *)(char *)bytes;
    }
}