#include "dir_entry.hpp"
#include "node.h"
#include <fstream>
#include <iostream>

using namespace std;

Node::Node(ifstream& ifs_, vector<uint32_t> cs)
    : ifs(ifs_), cluster_nos(cs)
{

}

auto Node::ExportTo(char const* path) -> bool
{
    ofstream ofs(path, ios_base::binary);

    for (auto& c: cluster_nos)
    {
        char buffer[0x1000] = {0};
        ifs.seekg(c, ios_base::beg);
        ifs.read(buffer, 0x1000);
        ofs.write(buffer, 0x1000);
    }

    return true;
}
