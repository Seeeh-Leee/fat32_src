
namespace io {
    int to_be(char* bytes);
    int to_le1(char* bytes);
    int to_le2(char* bytes);
    int to_le4(char* bytes);
}
