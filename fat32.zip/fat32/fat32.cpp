#include <vector>
#include <iostream>
#include <string>
#include "util.h"
#include "boot_record.h"
#include "fat_table.h"
#include "fat32.h"
#include "node.h"
#include "dir_entry.hpp"

using namespace std;


Fat32::Fat32(ifstream& ifs_)
    : ifs(ifs_)
{
    char buffer[0x200] = { 0 };
    ifs.read(buffer, 0x200);
    br = new BootRecord(buffer);

    ifs.seekg(br->fat1_area, ios_base::beg);
    vector<char> fat_bytes(br->fat_size);
    ifs.read(&fat_bytes[0], br->fat_size);   

    fat = new FatTable(&fat_bytes[0], br->fat_size);

    cout << hex << fat->next(0x96) << endl;
}


auto Fat32::GetNode(char const* name) -> Node*
{
    char buffer[0x20] = {0};
    ifs.seekg(0x404040, ios_base::beg);
    ifs.read(buffer, 0x20);
    auto leaf1 = new DirectoryEntry(buffer);

    vector<uint32_t> cluster_nos;

    uint32_t cur;
    
    cur = leaf1->start_cluster_num;
    
    while (cur != 0xfffffff)
    {

        auto addr = br->data_block_area + (cur-2)*0x1000;
        cout << "cur: " << cur << endl;
        //cout << "addr: " << addr << endl;
        //cout << "data block: " << br->data_block_area << endl;
        cluster_nos.push_back(addr);
        cur=fat->next(cur);
    }

    auto node = new Node(ifs, cluster_nos);

    return node;

}
