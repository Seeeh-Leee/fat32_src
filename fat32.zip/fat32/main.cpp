#include <iostream>
#include "fat32.h"
#include "node.h"

using namespace std;


int main(int argc, char *argv[])
{
    ifstream ifs(argv[1], ios_base::binary);

    Fat32 fat32(ifs);

    auto node = fat32.GetNode("sss");
    node->ExportTo("/home/handong/leaf.jpg");

    return 0;
}
