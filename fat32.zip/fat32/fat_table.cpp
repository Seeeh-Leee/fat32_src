#include "fat_table.h"
#include "util.h"

#include <vector>
#include <cstdint>

using namespace std;

FatTable::FatTable(char* buffer, int size)
{
    for (auto i=0; i<size; i+=4)
    {
        auto entry = io::to_le4(&buffer[i]);

        fat.push_back(entry);
    }
}

auto FatTable::next(uint32_t curr) -> uint32_t
{
    return fat[curr];
}
