#include <string>


using namespace std;

class DirectoryEntry
{
public:
    DirectoryEntry(char* buffer);

    string name;
    int start_cluster_num;

private:
    
    auto is_dir()   const { return false; }
};
