#include "boot_record.h"
#include "util.h"
#include <fstream>
#include <iomanip>
#include <iostream>

using namespace std;

BootRecord::BootRecord(char* buffer)
{
        bytes_per_sector = io::to_le2(buffer + 0x0b); //200
        sectors_per_cluster = io::to_le1(buffer + 0x0d); //8
        cluster_size = bytes_per_sector * sectors_per_cluster; //1000
        fat_count = io::to_le1(buffer + 0x10); //2

        reserved_area = io::to_le2(buffer + 0x0e); //10ae
        fat1_area = reserved_area * bytes_per_sector ; //215c00

        fat_sector_count = io::to_le4(buffer + 0x24); //7a9
        data_block_area = fat1_area + (fat_count * fat_sector_count * bytes_per_sector);
        

        fat_size = bytes_per_sector * fat_sector_count;
        
        cout <<"here" << endl;
        cout << hex << bytes_per_sector << endl;
        cout << hex << sectors_per_cluster << endl;
        cout << hex << cluster_size << endl;
        cout << hex << fat_count << endl;
        cout << hex << reserved_area << endl;
        cout << hex << fat_sector_count << endl;
        cout << hex << fat1_area << endl;
        cout << hex << data_block_area << endl;
        cout << hex << fat_size << endl;
    cout << " end "<<endl;
}
