#pragma once

#include <vector>
#include <cstdint>
#include <fstream>

class FatTable;
class BootRecord;
class Node;

using namespace std;

class Fat32
{
public:
    Fat32(ifstream& ifs_);
    auto GetNode(char const* name) -> Node*;


    ifstream& ifs;
    FatTable* fat;
    BootRecord* br;
};
