#include <iostream>
#include <fstream>
#include <string>
#include "boot_record.h"
#include "dir_entry.hpp"

#include "util.h"

using namespace std;

DirectoryEntry::DirectoryEntry(char* buffer)
{
    int attr = io::to_le1(buffer + 0x0b);

    string n(buffer, 0,8);
    name = n;

    cout << name << endl;

    auto start_cluster_hi = io::to_le2(buffer + 0x14);
    auto start_cluster_lo = io::to_le2(buffer + 0x1a);

    start_cluster_num = (start_cluster_hi << 16) | start_cluster_lo; //0x06

    cout << "hi " << (start_cluster_hi << 16) << endl;
    cout << "num " << (start_cluster_num) << endl;
}
